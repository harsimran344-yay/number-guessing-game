# number-guessing-game

# What does it do
Will generate a random number between 1 and 100
Asks user to input a number to guess
User will have 10 chances to guess
User unable to guess in 10 turns - set game over and user can restart the game by reset button
User guess the answer right - Whooo! a Congratulations message will be shown and can restart the game
A hint will be provided on every submission whether the answer is higher or lower
